<?php

require_once 'config.php';

$page = isset($_GET['page']) ? $_GET['page'] : '';

if ($page == 'web-developing') {

	$onload = "onload='Web();'";
} else if ($page == 'portfolio') {

	$onload = "onload='Port();'";
} else if ($page == 'blog') {

	$onload = "onload='Blog();'";
} else if ($page == 'design') {

	$onload = "onload='Design();'";
} else if ($page == 'programming') {

	$onload = "onload='Programming();'";
} else if ($page == 'seo') {

	$onload = "onload='Seo();'";
} else if ($page == 'marketing') {

	$onload = "onload='Marketing();'";
} else {

	$onload = '';
}

?>
<!doctype html>
<html lang='en'>
<head>
	<meta charset='utf-8'>
	<meta name='description' content='...'>
	<meta name='keywords' content='...'>
	<meta name='author' content='Milos Toplicic'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<link rel='icon' type='image/png' href='look/img/favicon-orange.png'>
	<link rel='stylesheet' type='text/css' href='look/fonts/font-awesome-4.7.0/css/font-awesome.min.css'>
	<link rel='stylesheet' type='text/css' href='look/css/style.css'>
	<title>Skupra Organization</title>
	<script>
		
		function Web() {
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			var z = document.getElementById("blog");
			if (x.style.height === "none") {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
			} else {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
			}
		}

		function Port() {
			var y = document.getElementById("portfolio");
			var x = document.getElementById("web-developing");
			var z = document.getElementById("blog");
			if (y.style.display === "none") {
				
				y.style.display = "block";
				x.style.display = "none";
				z.style.display = "none";
			} else {
				
				y.style.display = "block";
				x.style.display = "none";
				z.style.display = "none";
			}
		}
		
		function Blog() {
			var z = document.getElementById("blog");
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			if (z.style.display === "none") {
				
				z.style.display = "block";
				x.style.display = "none";
				y.style.display = "none";
			} else {
				
				z.style.display = "block";
				x.style.display = "none";
				y.style.display = "none";
			}
		}

		function Site() {
			var z = document.getElementById("blog");
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			var x1 = document.getElementById("design");
			var y1 = document.getElementById("programming");
			var z1 = document.getElementById("seo");
			var q1 = document.getElementById("marketing");
			
			z.style.display = "none";
			x.style.display = "none";
			y.style.display = "none";
			x1.style.display = "none";
			y1.style.display = "none";
			z1.style.display = "none";
			q1.style.display = "none";
		}

		window.onscroll = function() {scrollFunction()};

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				
				document.getElementById("topbtn").style.display = "block";
			} else {
				
				document.getElementById("topbtn").style.display = "none";
			}
		}

		function topFunction() {
			
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}

		function Design() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "none";
			} else {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "none";
			}
		}

		function Programming() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "block";
				z.style.display = "none";
				q.style.display = "none";
			} else {
				
				x.style.display = "none";
				y.style.display = "block";
				z.style.display = "none";
				q.style.display = "none";
			}
		}

		function Seo() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "block";
				q.style.display = "none";
			} else {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "block";
				q.style.display = "none";
			}
		}

		function Marketing() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "block";
			} else {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "block";
			}
		}

		function MoreSite() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			
			x.style.display = "none";
			y.style.display = "none";
			z.style.display = "none";
			q.style.display = "none";
		}
	</script>
</head>

<body <?php echo $onload; ?>>
	<p><a href='<?php echo $home; ?>'><img title='English' id='en' src='look/img/en.png'></a><a href='<?php echo $home.'sr'; ?>'><img title='Serbian' id='sr' src='look/img/sr.png'></a></p>
	<button onclick="topFunction(); Site();" id="topbtn" title="Go to top">Top</button>
	<div id='logo'>
		<img id='img_logo' src='look/img/logo-orange.png' onmouseover="this.src='look/img/logo-white.png'" onmouseout="this.src='look/img/logo-orange.png'">
		<h1><a href="#logo" onclick="Site()">Skupra Organization</a></h1>
		<p><a href="#web-developing" onclick="Web()">Web Developing</a><a href="#portfolio" onclick="Port()">Portfolio</a><a href="#blog" onclick="Blog()">Blog</a></p>
	</div>
	<div id='web-developing'>
		<h1>Web Developing</h1>
		<br>
		<h2><u>Our Services</u></h2>
		<div class='block2'>
			<h3><a href="#design" onclick="Design()"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i> WEB DESIGN</a></h3>
			<p>Our main virtue is intelligence in a perfect composition with art. Everyone knows that beauty is in the eye of the beholder, so we will not discuss about that. However, we will not only make your website, project or application functional. We will give them style, design and elegance.</p>
		</div>
		<div class='block2'>
			<h3><a href="#programming" onclick="Programming()"><i class="fa fa-cogs fa-2x" aria-hidden="true"></i> WEB PROGRAMMING</a></h3>
			<p>By using latest technology and tools, together we can find functional solutions. Our websites works well on multiple devices with different screen sizes. Our programmers use a PHP libraries and MySQL Community Server.</p>
		</div>
		<div class='block2'>
			<h3><a href="#seo" onclick="Seo()"><i class="fa fa-tachometer fa-2x" aria-hidden="true"></i> SEO OPTIMIZATION</a></h3>
			<p>„Doing business without advertising is like winking at a girl in the dark. You know what you are doing but nobody else does“. It is similar with your website. That is why we need SEO. Search Engine Optimization (SEO) is the process of optimizing your online content, so that a search engine likes to show it as a top result for searches of a certain keyword.</p>
		</div>
		<div class='block2'>
			<h3><a href="#marketing" onclick="Marketing()"><i class="fa fa-users fa-2x" aria-hidden="true"></i> MARKETING</a></h3>
			<p>Besides regular advertisement, we could also post your banners, announcement, follow your official page at social network, etc. With a wide group of followers, your internet rating will also grow.</p>
		</div>
		<br>
		<h2><u>Get in close</u></h2>
		<div class='block2'>
			<h3><i class="fa fa-phone-square" aria-hidden="true"></i> Contact</h3>
			<p>
				Belgrade, Serbia<br><br>
				Viber: +381 61 132 54 57<br>
				E-Mail: office@skupra.org<br>
				Skype: mastertango82
			</p>
		</div>
		<div class='block2'>
			<h3><i class="fa fa-database" aria-hidden="true"></i> Hosting</h3>
			<p>
				We create websites, product websites, landing pages, application. We are also a wholesaler of domain and other services such as web hosting. We are using our own servers with response over 99% and hundreds of satisfied customers.
			</p>
		</div>
	</div>
	<div id='design'>
		<h2>Web Design <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>It is very difficult to an average user to distinguish web design and web programming. So called <b>frontend</b> (where web design belongs) and <b>backend</b>. It covers design of web pages or website and design of additional elements like navigation, logo, forms and buttons as well.<br><br>
		A web designer should know basics of programming in order to combine a website with design. Some software for digital image processing have option to create templates. And then it is necessary to adjust a template with a website.<br><br>
		A web designer also has to be familiar with tools and application, such as wordpress, joomla, drupal and many other parts of a code.<br><br>
		In case where web designer and web programmer have good cooperation, implementation is done together.<br><br>
		Nowadays, a significant number of programmers develops design skills in order to work independently as a freelancers</p>
	</div>
	<div id='programming'>
		<h2>Web Programming <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		Web programming and web design are two completely different jobs. A programmer is a person who is responsible for a contraction of website. A designer can not enable functionality of website. And this is a moment when programmer comes in. To make a website functional, a programmer can use well – known codes or to create his/her own.<br><br>
		In my opinion, programmer who creates a code always has an advantage. This process is a little bit slower and more expensive, however it is a choice between a fast, functional website that can be upgraded against the one that can not. If you have a website based on a existing code than you will need an administrator.<br><br>
		For a programmer who write his/her own code, at the first place is functionality. In this case, there is no place for unnecessary parts of the code. This is one of the reasons why client has to know what exactly wants, static or dynamic website. How many pages do they want? Do they want a website that work well on multiple devices in different languages? Etc…<br><br>
		Communication between a client and a programmer is one of essential matters. Each client has a different request. Some of them just want a website with contact details. On the other hand, others have clear request.<br><br>
		It is really hard to judge how much a website cost. A cost depends on the type of domain you choose, web design, quality, etc.
		</p>
	</div>
	<div id='seo'>
		<h2>SEO Optimization <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		<b>SEO</b> is a technical, analytical and creative process to improve the visibility of a website in search engine. A website must not have any semantic or syntax errors. By checking a webpage source you can see if the websites has been correctly conceived. If all lines have been closed, if each picture has a description, etc…<br><br>
		SEO depends on website. Because it is a long-term job, we always suggest to client that we administrate the website. Our final aim is that your website appeares first in a search list.<br><br>
		It means that new subjects are necessary, existing of key words. Website has to be dedicated to its subjest. For example, if you administrate a website about agriculture, it would be good to have links with agricultural machinery.<br><br>
		Web browsers works on statistical principle. If some website has many visits than a browser will pay attention at that website.<br><br>
		If your website was created in five days and only left at the Internet, browsers would forget it… <b>SEO is a marathon, not a sprint.</b>
		</p>
	</div>
	<div id='marketing'>
		<h2>Marketing <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		It may sound absurd, but agencies do not put enough effort to thoroughly examine marketing. A good website is not just a combination of neat web design and new technologies- it is primarily an effective and powerful tool for achieving your business goals. To get somewhere you want, you should first plan the way. The same simple rule is true for websites. If you don’t market them well, they will fail to meet their objectives, generating unreasonable expense instead of profit. We can help you with this.<br><br>
		You will decide if that will be direct marketing, internet marketing, ets. We could also be your PR service. Nowdays, everyone use internet and there is a lot of ways to approach them: social networks, photo sharing, business cards, flyers. There is a lot of possibilities for jobs and advertising. And advertising is a job with a human touch. We could also offer to you consultation or presentation. And the most important thing <b>do you want that website advertise you or you to advertise a website</b>.
		</p>
	</div>
	<div id='portfolio'>
		<h1>Portfolio</h1>
		<br>
		<h2><u>Our Work</u></h2>
		<br>
		<div class='block2'>
			<a target="_blank" href='https://www.drileda.com'><img class='img1' src='content/img/drileda.jpg'>
				<p class='smallt'>Drileda Blog Website. Our personal seal. We're still in talks with the owner. The question is whether the blog will live and at what address. We, as usual, put all our jobs here.<br><br>
				https://www.drileda.com</p>
			</a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://tvojakuvarica.com'><img class='img1' src='content/img/tvojakuvarica.jpg'>
				<p class='smallt'>Hi, my name is Marina and I am administrator of the website tvojakuvarica.com. I am very satisfied with the cooperation with the Skupra team. They created my website and showed me how to maintain it in the future. Together, we have posted a few advertisement that brought us additonal income. My recommendation.<br><br>
					https://tvojakuvarica.com
				</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://www.born-to-run-serbia.org'><img class='img1' src='content/img/borntorun.jpg'>
			<p class='smallt'>"Born to run" is our common site. And dedicated to the positive energy generated by participating in races and marathons as well as various human actions. This creates a collective positive energy and can only be useful.<br><br>
				https://www.born-to-run-serbia.org
			</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://dnoviblog.skupra.org'><img class='img1' src='content/img/dnoviblog.jpg'>
				<p class='smallt'>This blog has been created in cooperation with freelancers from around the world. It was used PHP programming language without any additions. It is highspeed blog visible on multiple devices. We are very proud on this work, because in a meantime we have built our framework, a class for implementation on other websites.<br><br>
					https://dnoviblog.skupra.org
				</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://digitalagencynetwork.com/agencies/san-francisco'><img class='img1' src='content/img/sanfrancisco.jpg'>
				<p class='smallt'>The Skupra organization helped us set up the site, for the location of San Francisco. We used a ruthless way of presenting, so the site is available on mobile devices. All praise from the team of the digital agency.<br><br>
				https://digitalagencynetwork.com/agencies/san-francisco
			</p></a>
		</div>
	</div>
	<div id='blog'>
		<h1>Blog</h1>
	</div>
</body>
</html>