<?php

require_once '../config.php';

$page = isset($_GET['page']) ? $_GET['page'] : '';

if ($page == 'web-developing') {

	$onload = "onload='Web();'";
} else if ($page == 'portfolio') {

	$onload = "onload='Port();'";
} else if ($page == 'blog') {

	$onload = "onload='Blog();'";
} else if ($page == 'design') {

	$onload = "onload='Design();'";
} else if ($page == 'programming') {

	$onload = "onload='Programming();'";
} else if ($page == 'seo') {

	$onload = "onload='Seo();'";
} else if ($page == 'marketing') {

	$onload = "onload='Marketing();'";
} else {

	$onload = '';
}

?>
<!doctype html>
<html lang='sr'>
<head>
	<meta charset='utf-8'>
	<meta name='description' content='...'>
	<meta name='keywords' content='...'>
	<meta name='author' content='Милош Топличић'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<link rel='icon' type='image/png' href='../look/img/favicon-orange.png'>
	<link rel='stylesheet' type='text/css' href='../look/fonts/font-awesome-4.7.0/css/font-awesome.min.css'>
	<link rel='stylesheet' type='text/css' href='../look/css/style.css'>
	<title>Skupra Organization</title>
	<script>
		
		function Web() {
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			var z = document.getElementById("blog");
			if (x.style.height === "none") {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
			} else {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
			}
		}

		function Port() {
			var y = document.getElementById("portfolio");
			var x = document.getElementById("web-developing");
			var z = document.getElementById("blog");
			if (y.style.display === "none") {
				
				y.style.display = "block";
				x.style.display = "none";
				z.style.display = "none";
			} else {
				
				y.style.display = "block";
				x.style.display = "none";
				z.style.display = "none";
			}
		}
		
		function Blog() {
			var z = document.getElementById("blog");
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			if (z.style.display === "none") {
				
				z.style.display = "block";
				x.style.display = "none";
				y.style.display = "none";
			} else {
				
				z.style.display = "block";
				x.style.display = "none";
				y.style.display = "none";
			}
		}

		function Site() {
			var z = document.getElementById("blog");
			var x = document.getElementById("web-developing");
			var y = document.getElementById("portfolio");
			var x1 = document.getElementById("design");
			var y1 = document.getElementById("programming");
			var z1 = document.getElementById("seo");
			var q1 = document.getElementById("marketing");
			
			z.style.display = "none";
			x.style.display = "none";
			y.style.display = "none";
			x1.style.display = "none";
			y1.style.display = "none";
			z1.style.display = "none";
			q1.style.display = "none";
		}

		window.onscroll = function() {scrollFunction()};

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				
				document.getElementById("topbtn").style.display = "block";
			} else {
				
				document.getElementById("topbtn").style.display = "none";
			}
		}

		function topFunction() {
			
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}

		function Design() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "none";
			} else {
				
				x.style.display = "block";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "none";
			}
		}

		function Programming() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "block";
				z.style.display = "none";
				q.style.display = "none";
			} else {
				
				x.style.display = "none";
				y.style.display = "block";
				z.style.display = "none";
				q.style.display = "none";
			}
		}

		function Seo() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "block";
				q.style.display = "none";
			} else {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "block";
				q.style.display = "none";
			}
		}

		function Marketing() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			if (x.style.display === "none") {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "block";
			} else {
				
				x.style.display = "none";
				y.style.display = "none";
				z.style.display = "none";
				q.style.display = "block";
			}
		}

		function MoreSite() {
			var x = document.getElementById("design");
			var y = document.getElementById("programming");
			var z = document.getElementById("seo");
			var q = document.getElementById("marketing");
			
			x.style.display = "none";
			y.style.display = "none";
			z.style.display = "none";
			q.style.display = "none";
		}
	</script>
</head>

<body <?php echo $onload; ?>>
	<p><a href='<?php echo $home; ?>'><img title='English' id='en' src='../look/img/en.png'></a><a href='<?php echo $home.'sr'; ?>'><img title='Serbian' id='sr' src='../look/img/sr.png'></a></p>
	<button onclick="topFunction(); Site();" id="topbtn" title="Идемо Горе">Горе</button>
	<div id='logo'>
		<img id='img_logo' src='../look/img/logo-orange.png' onmouseover="this.src='../look/img/logo-white.png'" onmouseout="this.src='../look/img/logo-orange.png'">
		<h1><a href="#logo" onclick="Site()">Скупра Организација</a></h1>
		<p><a href="#web-developing" onclick="Web()">Веб Развој</a><a href="#portfolio" onclick="Port()">Портфолио</a><a href="#blog" onclick="Blog()">Блог</a></p>
	</div>
	<div id='web-developing'>
		<h1>Веб Развој</h1>
		<br>
		<h2><u>Наше Услуге</u></h2>
		<div class='block2'>
			<h3><a href="#design" onclick="Design()"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i> ВЕБ ДИЗАЈН</a></h3>
			<p>Са поносом можемо рећи, да поседујемо уметничке црте у нашим способностима. Тако да имамо осећај за лепо. О укусима, наравно не треба расправљати, али поред сувог програмирања, спремни смо да заједно улепшамо Ваш веб сајт, неки пројекат или апликацију.</p>
		</div>
		<div class='block2'>
			<h3><a href="#programming" onclick="Programming()"><i class="fa fa-cogs fa-2x" aria-hidden="true"></i> ВЕБ ПРОГРАМИРАЊЕ</a></h3>
			<p>У сарадњи са вама, заједно долазимо до функционалног решења. Користимо савремене технологије и алате. Сваки наш сајт је прилагодљив свим уређајима, без обзира на величину екрана. Програмирамо у <b>PHP</b> језику, користећи библиотеке, као и <b>MySQL</b> везу са базом података.</p>
		</div>
		<div class='block2'>
			<h3><a href="#seo" onclick="Seo()"><i class="fa fa-tachometer fa-2x" aria-hidden="true"></i> СЕО ОПТИМИЗАЦИЈА</a></h3>
			<p>Ништа Вам не значи да имате веб сајт, ако нико не зна за њега. <b>SEO</b> оптимизација је скуп поступака, који се изводе над веб сајтом, да би он био боље позициониран на интернету, у свим претраживачима, као и одабир кључних речи преко којих вас клијенти или друге особе могу наћи на интернету.</p>
		</div>
		<div class='block2'>
			<h3><a href="#marketing" onclick="Marketing()"><i class="fa fa-users fa-2x" aria-hidden="true"></i> МАРКЕТИНГ</a></h3>
			<p>Поред аутоматског презентовања и рекламирања Ваших радова, пројеката и сајтова, ми то можемо урадити и на директан начин, постављајући рекламне банере, огласе, можемо бити чланови група на друштвеним мрежама и рекламирати Вас. На тај начин повећавате број посетилаца а самим тим и интернет рејтинг.</p>
		</div>
		<br>
		<h2><u>Приђимо ближе</u></h2>
		<div class='block2'>
			<h3><i class="fa fa-phone-square" aria-hidden="true"></i> Контакт</h3>
			<p>
				Београд, Србија<br><br>
				Вибер: +381 61 132 54 57<br>
				Е-пошта: office@skupra.org<br>
				Скајп: mastertango82
			</p>
		</div>
		<div class='block2'>
			<h3><i class="fa fa-database" aria-hidden="true"></i> Хостинг</h3>
			<p>
				Осим послова око израде сајтова и веб апликација, вршимо услуге хостинга и продаје домена. Имамо своје сервере и одзив је преко 99% и стотине задовољних клијената.
			</p>
		</div>
	</div>
	<div id='design'>
		<h2>Веб Дизајн <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		Данас је јако тешко одвојити веб дизајн и веб програмирање. Такозвани <b>frontend</b> и  <b>backend</b>. Дизајн спада у <b>frontend</b>. Односи се на дизајнирање делова странице, или комплетног сајта, као и дизајнирање посебних елемената, као што су навигација, лого, форме, дугмад.<br><br>
		Веб дизајнер мора да познаје и основе програмирања, да би могао да уклопи сајт са дизајном. Такође у неким програмима за обраду слика, постоји опција да се направи шаблон. И онда је тај шаблон потребно уклопити у сајт.<br><br>
		Али, веб дизајнер такође мора да зна да користи готове алате и апликације, као што су <b>wordpress</b>, <b>joomla</b>, <b>drupal</b> као и многе самосталне делове кода.<br><br>
		Генерално, ако је сарадња веб дизајнера са веб програмером добра, онда тај посао имплементације, раде заједно или по договору.<br><br>
		Данас се све више програмери окрећу ка томе, да развију код себе дизајнерске вештине не би ли могли да раде сами као самостални предузетници, односно фриленсери.
		</p>
	</div>
	<div id='programming'>
		<h2>Веб Програмирање <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		Веб програмирање је комплекснији посао од веб дизајна. Јер <b>програмер</b> увек може да ради самостално, док дизајнер јако тешко може да направи функционалан сајт. Ту на сцену ступа програмер. Он мора да познаје најновије технологије и да их примењује. Може писати свој програм, или користити туђе делове кода које програмери деле путем одређених заједница.<br><br>
		Ја, лично, увек дајем предност програмерима који пишу свој код. Тако је процес до некле спорији и на крају испадне скупље за клијента. Али на клијенту је да одлучи, да ли жели брз, флексибиалан сајт подложан надоградњи. Или жели предефинисан систем, који онда мора да одржава свакодневно, а ту онда мора да упосли и неког администратора.<br><br>
		Код самосталног писања програма за веб сајт, акценат се даје на тачну функционалност сајта. Не оптерећује се сајт беспотребним деловима кода, већ само шта је задато. Тако да клијент мора да буде прецизан шта заправо жели. Статичан или динамичан сајт. Са одређеним бројем страна или са недефинисаним бројем страна. Да ли сајт треба бити прилагодљив мобилним уређајима који имају мање екране, да ли жели вишејезичан сајт итд…
		<br><br>
		Јако је битна ту комуникација између клијента и програмера. Ми смо имали послове од тога да клијент жели било какав сајт, само да стави контакт податке, до тога да се жели сајт тачно конципиран и дефинисан.<br><br>
		Од комплексности сајта, зависи и цена израде. Зато не можемо рећи чак ни оквирно које су цене у питању.
		</p>
	</div>
	<div id='seo'>
		<h2>СЕО Оптимизација <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		<b>SEO</b> оптимизација је скуп техника и алата, које се користе од стране програмера на сајту којем се жели побољшати рејтинг. Сајт не сме да има семантичке ни синтаксичке грешке. Прегледом извора странице утврђује се да ли је сајт добро конципиран. Да ли су затворене све линије, да ли постоје исправни линкови, да ли свака слика има опис итд…<br><br>
		СЕО оптимизација зависи од врсте сајта. То је дугорочан посао и ми увек предложимо клијенту да администрирамо направљен сајт, не би ли га извукли на прво место у претрази.<br><br>
		То подразумева да морају постојати нове теме, да се морају користити кључне речи. Да сам сајт буде строго прецизан и у својој сврси. На пример, ако је сајт о пољопривредним производима, пожељно је имати линкове ка неким пољопривредним машинама. И спољне и унутрашње линкове, као и линкове на другим сајтовима ка вама. То је јако битно.<br><br>
		Претраживачи ради на принципу статистике. Ако је неки сајт доста посећен, онда ће и претраживач чешће обраћати пажњу на тај сајт и изнова увек прегледати садржај.<br><br>
		А ако сте урадили сајт у року од 5 дана и оставили га да <b>чучи</b> на интернету, наравно да ће и претраживачи, првенствено <b>Goolge</b>, заборавити на њега. Зато се каже; <b>ако је СЕО део спорта, онда је он маратон а не спринт</b>.
		</p>
	</div>
	<div id='marketing'>
		<h2>Маркетинг <a href="#web-developing" onclick="MoreSite()"><i class="fa fa-times" aria-hidden="true"></i></a></h2>
		<p>
		Можда најбитнија ставка, недовољно истражена, је <b>маркетинг сајта</b>. Ви, ако желите да ваш сајт буде посећен, морате га сами волети и посећивати, надгледати, обнављати, уређивати. Да постављате нове слике и да вам сајт увек буде ажуран. Али то није део маркетинга. Део маркетинга је оно што ми можемо урадити за вас. Ако имате неки производ или услугу, дозволите нама да вас саслушамо и на основу ваших жеља, тако и да дефинишемо маркетинг шему.<br><br>
		Да ли ће то бити директни маркетинг, индиректни, интернет маркетинг или нешто слично, зависи од вас. Као што смо напоменули, можемо бити ваш ПР (public relations officer). Данас много људи користи интернет и треба им само прићи на прави начин. Ту су друштвене мреже, па размена рекламних слика са колегама, постављање адресе сајта на ваше визит-карте, штампање флајера. Много је послова и начина како да се изрекламирате. И то није посао за програм, то је посао за живу особу. Можемо да закажемо консултације или презентације. И оно најбитније морате се одлучити, да ли желите <b>да сајт рекламира вас или ви да рекламирате сајт</b>. Лоша су искуства ако то радите уједно.
		</p>
	</div>
	<div id='portfolio'>
		<h1>Портфолио</h1>
		<br>
		<h2><u>Наши Послови</u></h2>
		<br>
		<div class='block2'>
			<a target="_blank" href='https://www.drileda.com'><img class='img1' src='../content/img/drileda.jpg'>
				<p class='smallt'>Дриледа Блог Сајт. Наш лични печат. Још смо у преговорима са власником. Питање је да ли ће блог заживети и на којој адреси. Ми као и обично све наше послове стављамо овде.<br><br>
				http://www.drileda.com</p>
			</a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://tvojakuvarica.com'><img class='img1' src='../content/img/tvojakuvarica.jpg'>
				<p class='smallt'>Здраво, ја сам Марина и одржавам сајт tvojakuvarica.com. Задовољна сам сарадњом са Скупра тимом. Они су ми одрадили сајт и мене упутили, како да га одржавам и да стављам садржај. Добро може да се заради од реклама, које смо заједно поставили, јер је сајт веома посећен. Препорука моја.<br><br>
					https://tvojakuvarica.com
				</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://www.born-to-run-serbia.org'><img class='img1' src='../content/img/borntorun.jpg'>
			<p class='smallt'>"Борн то рун" је наш заједнички сајт. А посвећен позитивној енергији која се ствара учествовањем у тркама и маратонима као и разним хуманим акцијама. Тако се ствара колективна позитивна енергија и може само да буде корисно.<br><br>
			https://www.born-to-run-serbia.org
			</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://dnoviblog.skupra.org'><img class='img1' src='../content/img/dnoviblog.jpg'>
				<p class='smallt'>Овај Блог смо радили у сарадњи са фриленсерима широм света. Потпуно је рађен у чистом <b>ПХП (PHP)</b> језику, без популарних додатака. Одликује га велика брзина и могућност прилагођавања сваком екрану. Посебно смо поносни на овај рад, јер смо у међувремену израдили свој фрејмворк, тј. своје класе за имплементацију у друге сајтове.<br><br>
					https://dnoviblog.skupra.org
				</p></a>
		</div>
		<div class='block2'>
			<a target="_blank" href='https://digitalagencynetwork.com/agencies/san-francisco'><img class='img1' src='../content/img/sanfrancisco.jpg'>
				<p class='smallt'>Скупра Организација нам је помогла у подешавању сајта, за локацију Сан Франциско. Користили смо ратегљив начин презентовања, тако да је сајт доступан и на мобилним уређајима. Све похвале од тима дигиталне агенције.<br><br>
					https://digitalagencynetwork.com/agencies/san-francisco
			</p></a>
		</div>
	</div>
	<div id='blog'>
		<h1>Блог</h1>
	</div>
</body>
</html>