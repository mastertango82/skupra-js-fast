<?php

$home = '/www/skupra.org/';

?>